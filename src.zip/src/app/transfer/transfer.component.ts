import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  // }
  // transfer(){
  //   this.cust.retriveAdmin(id,password,).subscribe(data=>{
  //     this.account=data;
  //     sessionStorage.setItem("AuthenticateUser",String(data.id));
  //     console.log(this.account);
  //     this.router.navigate(['/casthome'])
  //   },error=>{
  //     this.condition=false;
  //     alert("!!!Invalid Credentials!!!");
  //   });
  }
  
}
