export class Account {
    id: number;
    name: string;
	acno: string;
	phone: string;
	email: string;
	balance:number;
	password:string;
}
